(function () {
'use strict';
var $ = function (id) { return document.getElementById(id); };
var deviceKey = '';
var pin = '';
var polling = false;
var pollTimer = 0;
var pollFails = 0, linkMisses = 0;   // consecutive and total missed telemetry replies
var busy = false;           // a long action (upload, recal, portal) is running: pause polling
function loadPin() { try { return localStorage.getItem('ms.pin.' + deviceKey) || ''; } catch (e) { return ''; } }
function savePin(p) { try { localStorage.setItem('ms.pin.' + deviceKey, p); } catch (e) {} }
function raw(path, opts) {
opts = opts || {};
opts.cache = 'no-store';   // every reading is live; never reuse an earlier response
opts.headers = Object.assign({ 'X-Auth-Token': pin }, opts.headers || {});
return (usb ? usbFetch(path, opts) : fetch(path, opts).catch(function () {
throw new Error('Can’t reach the device. Check that this phone is on its Wi-Fi.');
})).then(function (r) {
if (r.status === 401) { var e = new Error('unauthorized'); e.code = 401; throw e; }
if (r.ok) return r;
return r.json().catch(function () { return {}; }).then(function (j) { throw new Error(j.error || ('HTTP ' + r.status)); });
});
}
function api(path, opts) { return raw(path, opts).then(function (r) { return r.json(); }); }
function post(path, params) {
return api(path, { method: 'POST', body: new URLSearchParams(params || {}) });
}
var usb = null;   // { port, reader, writer, pending: {id: {res, rej, timer}}, nextId }
function usbLine(line) {
var m = /^@(\d+) (\d+) (\S+) ?(.*)$/.exec(line);
if (!m || !usb) return;
var p = usb.pending[m[1]];
if (!p) return;
delete usb.pending[m[1]];
clearTimeout(p.timer);
try {
var h = new Headers(), i;
if (m[3] !== '-') m[3].split(';').forEach(function (kv) { var e = kv.indexOf('='); if (e > 0) h.set(kv.slice(0, e), kv.slice(e + 1)); });
var bin = atob(m[4] || ''), bytes = new Uint8Array(bin.length);
for (i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
p.res(new Response(bytes, { status: Number(m[2]), headers: h }));
} catch (e) { p.rej(new Error('Garbled reply from the device.')); }
}
function usbFetch(path, opts) {
var u = usb;
if (!u) return Promise.reject(new Error('USB cable not connected.'));
var method = (opts.method || 'GET').toUpperCase();
if (opts.body) path += (path.indexOf('?') < 0 ? '?' : '&') + opts.body.toString();
return new Promise(function (res, rej) {
var id = u.nextId++;
var timer = setTimeout(function () { delete u.pending[id]; rej(new Error('The device didn’t answer over USB.')); }, opts.timeout || 4000);
u.pending[id] = { res: res, rej: rej, timer: timer };
u.writer.write(new TextEncoder().encode('@' + id + ' ' + method + ' ' + path + (opts.chunk ? ' ' + opts.chunk : '') + '\n')).catch(function (e) {
clearTimeout(timer); delete u.pending[id]; rej(new Error('USB write failed: ' + e.message));
});
});
}
function usbClose(u) {
u.reader.cancel().catch(function () {}).then(function () {
try { u.reader.releaseLock(); u.writer.releaseLock(); } catch (e) {}
return u.port.close();
}).catch(function () {});
}
function usbGone(u) {
if (usb !== u) return;
usb = null;
Object.keys(u.pending).forEach(function (k) { clearTimeout(u.pending[k].timer); u.pending[k].rej(new Error('USB cable disconnected.')); });
usbClose(u);
polling = false;
$('usbFilesGroup').classList.add('hidden');
setConn('bad', 'USB lost');
showGate('The USB cable was disconnected. Plug it back in and connect again.');
}
function usbPump(u) {
var dec = new TextDecoder(), buf = '';
(function pump() {
u.reader.read().then(function (r) {
if (r.done) { usbGone(u); return; }
buf += dec.decode(r.value, { stream: true });
var i;
while ((i = buf.indexOf('\n')) >= 0) { usbLine(buf.slice(0, i).replace(/\r$/, '')); buf = buf.slice(i + 1); }
if (buf.length > 100000) buf = '';
pump();
}).catch(function () { usbGone(u); });
})();
}
function usbHello(n) {
return api('/deviceid').catch(function (e) { if (n >= 3) throw e; return usbHello(n + 1); });
}
function usbConnect() {
var port;
$('pinErr').textContent = '';
navigator.serial.requestPort().then(function (p) {
port = p;
return port.open({ baudRate: 115200 });
}).then(function () {
usb = { port: port, reader: port.readable.getReader(), writer: port.writable.getWriter(), pending: {}, nextId: 1 };
$('pinErr').textContent = 'Connecting…';
usbPump(usb);
return usbHello(1);
}).then(function (d) {
deviceKey = d.id;
setDevName(d.name, d.devId);
$('devId').value = d.devId;
$('pinErr').textContent = '';
$('gate').classList.add('hidden');
setConn('ok', 'USB');
$('usbFilesGroup').classList.remove('hidden');
usbFilesList();
start();
}).catch(function (e) {
if (usb) { var u = usb; usb = null; usbClose(u); }
$('pinErr').textContent = e.name === 'NotFoundError' ? '' : 'USB: ' + e.message;
});
}
$('usbBtn').addEventListener('click', usbConnect);
if (navigator.serial) $('usbBtn').classList.remove('hidden'); else $('usbHint').classList.remove('hidden');
var noticeTimer = 0;
function showNotice(text, kind) {
var n = $('notice');
n.textContent = text;
n.className = 'notice' + (kind ? ' ' + kind : '');
clearTimeout(noticeTimer);
noticeTimer = setTimeout(function () { n.classList.add('hidden'); }, kind === 'error' ? 8000 : 4000);
}
$('notice').addEventListener('click', function (ev) { clearTimeout(noticeTimer); ev.currentTarget.classList.add('hidden'); });
var layerStack = [];       // open layers, topmost last
var layerClosers = {};     // name -> function that hides that layer's DOM
var pendingPops = 0;
function pushLayer(name, closer) {
layerStack.push(name);
layerClosers[name] = closer;
try { history.pushState({ layer: name }, ''); } catch (e) {}
}
function dismissLayer(name) {
var i = layerStack.lastIndexOf(name);
if (i < 0) return;
var closing = layerStack.splice(i);
for (var k = closing.length - 1; k >= 0; k--) layerClosers[closing[k]]();
try { pendingPops++; history.go(-closing.length); } catch (e) { pendingPops--; }
}
function dismissTopLayer() { if (layerStack.length) dismissLayer(layerStack[layerStack.length - 1]); }
window.addEventListener('popstate', function () {
if (pendingPops > 0) { pendingPops--; return; }   // our own history.go()
var name = layerStack.pop();                       // a real back gesture: one layer per swipe
if (name) layerClosers[name]();
});
if (history.state && history.state.layer) { try { history.replaceState(null, ''); } catch (e) {} }
function execCopy(text) {
var ta = document.createElement('textarea');
ta.value = text;
ta.setAttribute('readonly', '');
ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0;';
document.body.appendChild(ta);
ta.select();
ta.setSelectionRange(0, text.length);
var ok = false;
try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
ta.remove();
return ok;
}
function copyText(text) {
if (navigator.clipboard && window.isSecureContext) {
return navigator.clipboard.writeText(text).then(function () { return true; }, function () { return execCopy(text); });
}
return Promise.resolve(execCopy(text));
}
function shareText(title, text) {
if (navigator.share) {
return navigator.share({ title: title, text: text }).catch(function (e) {
if (e && e.name === 'AbortError') return;
return copyShared(text);
});
}
return copyShared(text);
}
function copyShared(text) {
return copyText(text).then(function (ok) {
if (ok) showNotice('Copied. Paste it into a message to share it.', 'ok');
else showNotice('Couldn’t copy or open the share sheet on this browser.', 'error');
});
}
var confirmResolve = null, confirmReturnFocus = null, confirmResult = false;
function askConfirm(title, text, okLabel) {
return new Promise(function (resolve) {
$('confirmTitle').textContent = title;
$('confirmText').textContent = text;
$('confirmOk').textContent = okLabel;
confirmResolve = resolve;
confirmReturnFocus = document.activeElement;
$('confirmOverlay').classList.remove('hidden');
$('confirmCancel').focus();
pushLayer('confirm', finishConfirm);
});
}
function finishConfirm() {
$('confirmOverlay').classList.add('hidden');
var resolve = confirmResolve, result = confirmResult;
confirmResolve = null; confirmResult = false;
if (confirmReturnFocus && confirmReturnFocus.focus) confirmReturnFocus.focus();
confirmReturnFocus = null;
if (resolve) resolve(result);
}
function closeConfirm(result) { confirmResult = result; dismissLayer('confirm'); }
$('confirmCancel').addEventListener('click', function () { closeConfirm(false); });
$('confirmOk').addEventListener('click', function () { closeConfirm(true); });
$('confirmBackdrop').addEventListener('click', function () { closeConfirm(false); });
document.addEventListener('keydown', function (ev) {
if (!confirmResolve) { if (ev.key === 'Escape') dismissTopLayer(); return; }
if (ev.key === 'Escape') { ev.preventDefault(); closeConfirm(false); }
else if (ev.key === 'Tab') {
ev.preventDefault();
(document.activeElement === $('confirmCancel') ? $('confirmOk') : $('confirmCancel')).focus();
}
});
var exportPending = null, exportReturnFocus = null;
function saveCsvFile(filename, text) {
var url = URL.createObjectURL(new Blob([text], { type: 'text/csv;charset=utf-8' }));
var a = document.createElement('a');
a.href = url; a.download = filename;
document.body.appendChild(a); a.click(); a.remove();
setTimeout(function () { URL.revokeObjectURL(url); }, 5000);
}
function likelyCaptiveBrowser() { return /CaptiveNetworkSupport/i.test(navigator.userAgent) || /; wv\)/.test(navigator.userAgent); }
function downloadCsv(filename, text, subject) {
exportPending = { filename: filename, text: text };
var blocked = likelyCaptiveBrowser();
$('exportTitle').textContent = 'Export ' + subject.count + ' ' + (subject.count === 1 ? subject.one : subject.many) + ' as CSV';
$('exportText').textContent = blocked ? 'Copy it and paste it into a spreadsheet. This browser probably can’t save files.' : 'Save it as a file, or copy it and paste it into a spreadsheet.';
$('exportWhyText').textContent = 'The page you’re on may be the sign-in screen your phone shows for this Wi-Fi, and that browser can’t save files. Tap Copy instead, or open http://' + location.host + ' in Chrome or Safari, where Save file works.';
document.querySelector('.exportWhy').open = blocked;
document.querySelector('.exportPreview').open = false;
$('exportBox').value = text;
$('exportShare').classList.toggle('hidden', !navigator.share);
$('exportSave').classList.toggle('primary', !blocked);
$('exportCopy').classList.toggle('primary', blocked);
exportReturnFocus = document.activeElement;
$('exportOverlay').classList.remove('hidden');
$(blocked ? 'exportCopy' : 'exportSave').focus();
pushLayer('export', finishExport);
}
function finishExport() {
$('exportOverlay').classList.add('hidden');
$('exportBox').value = '';
exportPending = null;
if (exportReturnFocus && exportReturnFocus.focus) exportReturnFocus.focus();
exportReturnFocus = null;
}
$('exportSave').addEventListener('click', function () {
if (!exportPending) return;
try { saveCsvFile(exportPending.filename, exportPending.text); }
catch (e) { showNotice('This browser can’t save files here. Use Copy instead.', 'error'); return; }
showNotice('Saving… if nothing downloads, use Copy.', 'ok');
});
$('exportCopy').addEventListener('click', function () {
if (!exportPending) return;
copyText(exportPending.text).then(function (ok) {
if (ok) { showNotice('CSV copied. Paste it into a spreadsheet or note.', 'ok'); return; }
document.querySelector('.exportPreview').open = true;   // last resort: show the text, selected, so a long-press can copy it
var box = $('exportBox');
box.focus(); box.select(); box.setSelectionRange(0, box.value.length);
showNotice('Couldn’t copy automatically. The text is selected: copy it from the menu.', 'error');
});
});
$('exportShare').addEventListener('click', function () {
if (!exportPending || !navigator.share) return;
navigator.share({ title: exportPending.filename, text: exportPending.text }).catch(function (e) {
if (!(e && e.name === 'AbortError')) showNotice('Couldn’t open the share sheet. Use Copy instead.', 'error');
});
});
$('exportBox').addEventListener('focus', function (ev) { ev.target.select(); });
$('exportClose').addEventListener('click', function () { dismissLayer('export'); });
$('exportBackdrop').addEventListener('click', function () { dismissLayer('export'); });
function setDevName(n, custom) {
$('devName').textContent = n;
$('devId').placeholder = custom ? 'Motor Checker' : n;   // empty box = the default name shown here
}
function setConn(state, text) {
$('connStatus').className = 'statusPill ' + state;
$('connLabel').textContent = text;
}
function recalSay(text, cls) {
var e = $('recalMsg');
e.textContent = text || '';
e.className = 'status ' + (cls === 'bad' ? 'error' : (cls || ''));
}
function say(text, cls) {
var s = $('status');
s.textContent = text || '';
s.className = 'status ' + (cls === 'bad' ? 'error' : (cls || ''));
}
function showGate(msg) {
$('pinErr').textContent = msg || '';
$('gate').classList.remove('hidden');
$('pin').value = '';
$('pin').focus();
}
$('gateForm').addEventListener('submit', function (e) {
e.preventDefault();
pin = $('pin').value.trim();
api('/telemetry').then(function () {
savePin(pin);
$('gate').classList.add('hidden');
start();
}).catch(function (err) {
showGate(err.code === 401 ? 'That PIN doesn’t match.' : 'Can’t reach the device.');
});
});
function magText(m) { return m.p === '-' ? '–' : m.p + ' ' + m.g + ' G'; }
function signedG(m) { return m.p === 'N' ? m.g : (m.p === 'S' ? -m.g : 0); }
function newMag() { return { nMin: Infinity, nMax: 0, sMin: Infinity, sMax: 0 }; }
function newStat() { return { n: 0, sum: 0, rMax: 0, rMin: Infinity, tMin: Infinity, tMax: -Infinity, m: [newMag(), newMag()] }; }
function addMag(m, g) {
if (g > 0) { if (g < m.nMin) m.nMin = g; if (g > m.nMax) m.nMax = g; }
else if (g < 0) { g = -g; if (g < m.sMin) m.sMin = g; if (g > m.sMax) m.sMax = g; }
}
function addStat(st, rpm, temp, g1, g2) {
if (rpm > 0) { st.n++; st.sum += rpm; if (rpm > st.rMax) st.rMax = rpm; if (rpm < st.rMin) st.rMin = rpm; }
if (temp < st.tMin) st.tMin = temp;
if (temp > st.tMax) st.tMax = temp;
addMag(st.m[0], g1); addMag(st.m[1], g2);
}
function fmtRpm(v) { return isFinite(v) && v > 0 ? Math.round(v).toLocaleString() : '–'; }
function fmtG(v) { return isFinite(v) && v > 0 ? v + ' G' : '–'; }
function magRange(lo, hi) { return hi > 0 ? lo + '–' + hi + ' G' : '–'; }
function fmtC(v) { return isFinite(v) ? v.toFixed(1) + ' °C' : '–'; }
var liveStat = newStat();
var magCells = function (i) {
return [['N max', function (s) { return fmtG(s.m[i].nMax); }], ['N min', function (s) { return fmtG(s.m[i].nMin); }],
['S max', function (s) { return fmtG(s.m[i].sMax); }], ['S min', function (s) { return fmtG(s.m[i].sMin); }]];
};
var LIVE_STATS = {
rpm: [['Max', function (s) { return fmtRpm(s.rMax); }], ['Min', function (s) { return fmtRpm(s.rMin); }], ['Avg', function (s) { return s.n ? fmtRpm(s.sum / s.n) : '–'; }]],
temp: [['Min', function (s) { return fmtC(s.tMin); }], ['Max', function (s) { return fmtC(s.tMax); }]],
m1: magCells(0),
m2: magCells(1)
};
function buildLiveStats() {
Object.keys(LIVE_STATS).forEach(function (k) {
var box = $('st-' + k);
LIVE_STATS[k].forEach(function (c) {
var d = document.createElement('div'), l = document.createElement('span'), v = document.createElement('b');
l.textContent = c[0]; v.textContent = '–';
d.appendChild(l); d.appendChild(v); box.appendChild(d);
c.push(v);
});
});
}
function updateLiveStats() {
Object.keys(LIVE_STATS).forEach(function (k) {
LIVE_STATS[k].forEach(function (c) { c[2].textContent = c[1](liveStat); });
});
}
buildLiveStats();
$('statReset').addEventListener('click', function () { liveStat = newStat(); updateLiveStats(); });
$('graphClear').addEventListener('click', function () {
live.t = []; live.rpm = []; live.temp = []; live.m1 = []; live.m2 = [];
LIVE_GRAPHS.forEach(function (g) { g.view = null; });
showNotice('Graphs cleared', 'ok');
});
var LIVE_WIN_MS = 60000;
var live = { t: [], rpm: [], temp: [], m1: [], m2: [] };
var LIVE_GRAPHS = [
{ id: 'rpm', name: 'Speed', color: '--c-rpm', zero: true },
{ id: 'temp', name: 'Temperature', color: '--c-temp', dec: 1 },
{ id: 'm1', name: 'Magnet 1', color: '--good', sym: true },
{ id: 'm2', name: 'Magnet 2', color: '--c-m2', sym: true }
];
function pushLiveAt(wall, rpm, t) {
var last = live.t.length ? live.t[live.t.length - 1] : 0;
if (wall < last) wall = last;
live.t.push(wall); live.rpm.push(rpm); live.temp.push(t.tempC); live.m1.push(signedG(t.m1)); live.m2.push(signedG(t.m2));
var now = Date.now();
while (live.t.length && now - live.t[0] > LIVE_WIN_MS) {
live.t.shift(); live.rpm.shift(); live.temp.shift(); live.m1.shift(); live.m2.shift();
}
}
var OLED_DRAW_MS = 10;          // the OLED needs about this long to finish drawing after its tick
var clock = { samples: [], off: null, lastDev: -1 };
var ticks = [], lastTickT = -1, syncDelay = 200, syncStep = 250, shownRpm = null;
function noteClock(t0, t1, dev) {
clock.samples.push({ rtt: t1 - t0, off: Math.round((t0 + t1) / 2 - dev) });
if (clock.samples.length > 20) clock.samples.shift();
var best = clock.samples.slice().sort(function (a, b) { return a.rtt - b.rtt; }).slice(0, 3)
.sort(function (a, b) { return a.off - b.off; });
clock.off = best[Math.floor(best.length / 2)].off;
}
function resetTicks() { ticks = []; lastTickT = -1; clock.samples = []; clock.off = null; shownRpm = null; }
function takeTelemetry(t, t0, t1) {
$('temp').textContent = (t.tempD !== undefined ? t.tempD : t.tempC).toFixed(1) + ' °C';
$('m1').textContent = magText(t.m1D || t.m1);
$('m2').textContent = magText(t.m2D || t.m2);
if (t.hist && t.hist.length && t.uptimeMs !== undefined) {
if (t.uptimeMs < clock.lastDev) resetTicks();       // the stand restarted
clock.lastDev = t.uptimeMs;
noteClock(t0, t1, t.uptimeMs);
syncDelay = t.delay || 200;
syncStep = t.step || 250;
t.hist.forEach(function (h) {
if (h[0] <= lastTickT) return;
lastTickT = h[0];
ticks.push({ t: h[0], rpm: h[1] });
pushLiveAt(h[0] + clock.off, h[1], t);
addStat(liveStat, h[1], t.tempC, signedG(t.m1), signedG(t.m2));   // every reading counts, not just the ones a poll happened to see
});
if (ticks.length > 60) ticks.splice(0, ticks.length - 60);
} else {                                                // older firmware: one reading per poll, shown as it arrives
$('rpm').textContent = t.rpm.toLocaleString();
pushLiveAt(Date.now(), t.rpm, t);
addStat(liveStat, t.rpm, t.tempC, signedG(t.m1), signedG(t.m2));
}
updateLiveStats();
}
function updateShownRpm() {
if (clock.off === null || !ticks.length) return;
var devNow = Date.now() - clock.off - OLED_DRAW_MS, pick = null, i;
var stepAt = devNow - ((devNow % syncStep) + syncStep) % syncStep;
for (i = ticks.length - 1; i >= 0; i--) {
if (ticks[i].t + syncDelay <= stepAt) { pick = ticks[i]; break; }
}
if (pick && pick.rpm !== shownRpm) {
shownRpm = pick.rpm;
$('rpm').textContent = shownRpm.toLocaleString();
}
}
var themeCache = {}, themeAt = 0;
function themeVar(n) {   // getComputedStyle every frame is wasteful: look colours up once a second
var now = Date.now();
if (now - themeAt > 1000) { themeCache = {}; themeAt = now; }
return themeCache[n] || (themeCache[n] = cssVar(n));
}
function drawLive(g) {
var cv = $('g-' + g.id), W = cv.clientWidth, H = cv.clientHeight;
var label = g.name + ' over the last minute, now ' + $(g.id).textContent;
if (cv._label !== label) { cv.setAttribute('aria-label', label); cv._label = label; }
if (!W || !H) return;
var dpr = window.devicePixelRatio || 1;
if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); }
var c = cv.getContext('2d');
c.setTransform(dpr, 0, 0, dpr, 0, 0);
c.clearRect(0, 0, W, H);
var a = live[g.id], n = a.length, now = Date.now(), i;
var L = 40, R = 6, T = 6, B = 4, pw = W - L - R, ph = H - T - B;
var lo = Infinity, hi = -Infinity;
for (i = 0; i < n; i++) { if (a[i] < lo) lo = a[i]; if (a[i] > hi) hi = a[i]; }
if (!n) { lo = 0; hi = 1; }
if (g.zero) { lo = 0; hi = niceCeil(hi); }
else if (g.sym) { var m = Math.max(50, niceCeil(Math.max(Math.abs(lo), Math.abs(hi)))); lo = -m; hi = m; }
else { var mid = (lo + hi) / 2, span = Math.max(hi - lo, 1) * 1.25; lo = mid - span / 2; hi = mid + span / 2; }
var view = g.view || (g.view = { lo: lo, hi: hi });
view.lo += (lo - view.lo) * 0.18; view.hi += (hi - view.hi) * 0.18;
if (Math.abs(view.lo - lo) < (hi - lo) * 0.002) view.lo = lo;
if (Math.abs(view.hi - hi) < (hi - lo) * 0.002) view.hi = hi;
lo = view.lo; hi = view.hi;
var yOf = function (v) { return T + ph - (v - lo) / (hi - lo) * ph; };
c.font = '11px system-ui, sans-serif';
c.strokeStyle = themeVar('--border'); c.fillStyle = themeVar('--text-dim'); c.lineWidth = 1;
c.textAlign = 'right'; c.textBaseline = 'middle';
[lo, (lo + hi) / 2, hi].forEach(function (v) {
var y = Math.round(yOf(v)) + 0.5;
c.beginPath(); c.moveTo(L, y); c.lineTo(L + pw, y); c.stroke();
var txt = Math.abs(v) >= 1000 ? (v / 1000).toFixed(v % 1000 ? 1 : 0) + 'k' : String(Math.round(v * 10) / 10);
if (g.dec) txt = v.toFixed(g.dec);
c.fillText(txt, L - 6, Math.min(Math.max(y, T + 6), T + ph - 6));
});
var col = themeVar(g.color), px = 0, py = 0;
c.strokeStyle = col; c.lineWidth = 1.75; c.lineJoin = 'round';
c.beginPath();
var qx = 0, qy = 0, open = false;
for (i = 0; i < n; i++) {
px = L + pw * (1 - (now - live.t[i]) / LIVE_WIN_MS); py = yOf(a[i]);
if (open && live.t[i] - live.t[i - 1] < 1500) {
c.quadraticCurveTo(qx, qy, (qx + px) / 2, (qy + py) / 2);
} else {
if (open) c.lineTo(qx, qy);
c.moveTo(px, py);
}
qx = px; qy = py; open = true;
}
if (open) {
c.lineTo(qx, qy);
if (now - live.t[n - 1] < 1500) { px = L + pw; c.lineTo(px, qy); }
}
c.stroke();
if (n) { c.fillStyle = col; c.beginPath(); c.arc(px, qy, 3, 0, 6.2832); c.fill(); }
}
function drawLiveAll() { LIVE_GRAPHS.forEach(drawLive); }
function liveFrame() {
requestAnimationFrame(liveFrame);
if (document.hidden || !$('tab-live').classList.contains('active')) return;
updateShownRpm();
drawLiveAll();
}
requestAnimationFrame(liveFrame);
function poll() {
if (!polling) return;
if (busy) { pollTimer = setTimeout(poll, 500); return; }
var t0 = Date.now();
api('/telemetry', { timeout: 1000 }).then(function (t) {
pollFails = 0;
takeTelemetry(t, t0, Date.now());
setConn('ok', usb ? 'live · USB' : 'live');
pollTimer = setTimeout(poll, 60);   // the stand publishes a new reading every 100 ms: ask again just after each response
}).catch(function (err) {
if (err.code === 401) { polling = false; showGate('PIN changed. Enter the one on the screen.'); return; }
pollFails++; linkMisses++;
$('connStatus').title = linkMisses + ' missed ' + (linkMisses === 1 ? 'reply' : 'replies') + ' since this page opened (last: ' + err.message + ')';
if (pollFails >= 3) setConn('bad', 'disconnected');
pollTimer = setTimeout(poll, pollFails < 3 ? 100 : 1500);
});
}
function start() {
if (polling) return;
polling = true;
sync.lastAt = 0;   // sync the sequence library as soon as the connection is up
clearTimeout(pollTimer);
poll();
logInit();
api('/deviceconfig').then(function (c) {
$('channel').value = String(c.channel);
$('fwVer').textContent = 'v' + c.fw;
}).catch(function () {});
}
var tabBtns = document.querySelectorAll('.tabBtn');
tabBtns.forEach(function (b) {
b.addEventListener('click', function () {
tabBtns.forEach(function (x) { x.classList.toggle('active', x === b); x.setAttribute('aria-selected', x === b ? 'true' : 'false'); x.tabIndex = x === b ? 0 : -1; });
document.querySelectorAll('.tab').forEach(function (t) { t.classList.toggle('active', t.id === 'tab-' + b.dataset.tab); });
if (b.dataset.tab === 'live') { drawLiveAll(); if (rec.on) renderRec(); else updateCapacity(); }
});
});
$('tabBar').addEventListener('keydown', function (e) {
var i = [].indexOf.call(tabBtns, document.activeElement), n = tabBtns.length;
if (i < 0 || ['ArrowRight', 'ArrowLeft', 'Home', 'End'].indexOf(e.key) < 0) return;
e.preventDefault();
var to = e.key === 'Home' ? 0 : e.key === 'End' ? n - 1 : (i + (e.key === 'ArrowRight' ? 1 : n - 1)) % n;
tabBtns[to].focus();
tabBtns[to].click();
});
$('homeBtn').addEventListener('click', function () {
if (layerStack.indexOf('settings') >= 0) dismissLayer('settings');
document.querySelector('[data-tab=live]').click();
window.scrollTo(0, 0);
});
function settingStatus(id, text, cls) { var e = $(id); e.textContent = text; e.className = 'status ' + (cls || ''); }
function closeSettingsDom() {
document.body.classList.remove('settingsOpen');
$('settingsPage').classList.add('hidden');
$('settingsBtn').setAttribute('aria-pressed', 'false');
}
function openSettings() {
document.body.classList.add('settingsOpen');
$('settingsPage').classList.remove('hidden');
$('settingsBtn').setAttribute('aria-pressed', 'true');
$('newPin').value = '';
window.scrollTo(0, 0);
pushLayer('settings', closeSettingsDom);
}
$('settingsBtn').addEventListener('click', function () { if (layerStack.indexOf('settings') >= 0) dismissLayer('settings'); else openSettings(); });
$('settingsBack').addEventListener('click', function () { dismissLayer('settings'); });
$('renameBtn').addEventListener('click', function () {
post('/setdeviceid', { id: $('devId').value }).then(function (r) {
setDevName(r.name, r.devId);
settingStatus('deviceIdStatus', 'The Wi-Fi is now “' + r.name + '”. Rejoin it in a moment.', 'ok');
}).catch(function (e) { settingStatus('deviceIdStatus', e.message, 'error'); });
});
function changePin(value) {
if (value && !/^\d{6}$/.test(value)) { settingStatus('pinStatus', 'The PIN must be exactly 6 digits.', 'error'); return; }
var old = pin;
busy = true;                       // keep the live poll from racing the change with the old PIN
post('/setpin', { pin: value }).then(function (r) {
pin = r.pin;
if (!usb) savePin(pin);
$('newPin').value = '';
settingStatus('pinStatus', 'PIN changed to ' + r.pin + '. Every other phone has to enter it.', 'ok');
showNotice('PIN changed', 'ok');
}).catch(function (e) {
pin = old;
settingStatus('pinStatus', e.message, 'error');
}).then(function () { busy = false; });
}
$('pinSaveBtn').addEventListener('click', function () { changePin($('newPin').value.trim()); });
$('pinRandomBtn').addEventListener('click', function () { changePin(''); });
var CRC_TABLE = null;
function crc32(u8) {
if (!CRC_TABLE) {
CRC_TABLE = [];
for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; CRC_TABLE[n] = c >>> 0; }
}
var crc = 0xFFFFFFFF;
for (var i = 0; i < u8.length; i++) crc = CRC_TABLE[(crc ^ u8[i]) & 0xFF] ^ (crc >>> 8);
return (crc ^ 0xFFFFFFFF) >>> 0;
}
function b64(u8) {
var s = '';
for (var i = 0; i < u8.length; i++) s += String.fromCharCode(u8[i]);
return btoa(s);
}
var USB_CHUNK = 96;    // raw bytes per line: 128 base64 characters. The stand’s USB receive buffer is only 256 bytes and the display redraw can stall the loop, so a whole line has to fit in it.
function usbSendFile(name, u8, onProgress) {
return api('/fsbegin?name=' + name + '&size=' + u8.length, { method: 'POST' }).then(function () {
var off = 0;
return (function next() {
if (off >= u8.length) return api('/fsend?size=' + u8.length + '&crc=' + crc32(u8), { method: 'POST' });
var part = u8.subarray(off, off + USB_CHUNK);
var line = b64(part), tries = 0;
var send = function () {
return api('/fschunk?off=' + off, { method: 'POST', chunk: line }).catch(function (e) {
if (/didn.t answer/.test(e.message) && ++tries < 4) return send();   // the reply or the line was lost: resend (the stand ignores a repeat)
throw e;
});
};
return send().then(function () {
off += part.length;
onProgress(off);
return next();
});
})();
});
}
function usbFilesList() {
api('/fslist').then(function (list) {
$('usbFilesList').textContent = list.length
? 'On the stand now: ' + list.map(function (f) { return f.name.replace('/www/', '') + ' (' + f.size + ' B)'; }).join(', ') + '.'
: 'No web files on the stand yet.';
}).catch(function () { $('usbFilesList').textContent = ''; });
}
function usbUploadAll(files) {
var total = files.reduce(function (a, f) { return a + f.u8.length; }, 0), done = 0, i = 0;
var msg = $('usbFilesMsg');
$('usbFilesBtn').disabled = $('usbFilesSelfBtn').disabled = true;
$('usbFilesMeter').classList.remove('hidden');
busy = true;
return (function next() {
if (i >= files.length) return;
var f = files[i++];
msg.textContent = 'Sending ' + f.name.replace('/www/', '') + ' (' + i + ' of ' + files.length + ')…';
msg.className = 'status';
return usbSendFile(f.name, f.u8, function (off) { $('usbFilesBar').style.width = ((done + off) * 100 / total) + '%'; }).then(function () {
done += f.u8.length;
return next();
});
})().then(function () {
msg.textContent = 'Done: ' + files.length + (files.length === 1 ? ' file' : ' files') + ' sent and verified. Reload the stand’s page from Wi-Fi to see them.';
msg.className = 'status ok';
showNotice('Web files updated', 'ok');
}).catch(function (e) {
msg.textContent = 'Stopped: ' + e.message + ' Files already sent are in place; the rest are unchanged.';
msg.className = 'status error';
}).then(function () {
busy = false;
$('usbFilesBtn').disabled = $('usbFilesSelfBtn').disabled = false;
$('usbFilesMeter').classList.add('hidden');
$('usbFilesBar').style.width = '0';
usbFilesList();
});
}
function confirmUpload(files) {
return askConfirm('Replace the stand’s web files?', files.map(function (f) { return f.name.replace('/www/', ''); }).join(', ') + ' will be replaced. Keep the cable connected until it finishes.', 'Replace');
}
$('usbFilesBtn').addEventListener('click', function () {
var picked = $('usbFilePick').files;
if (!picked.length) { $('usbFilesMsg').textContent = 'Choose the .gz files first.'; $('usbFilesMsg').className = 'status error'; return; }
Promise.all([].map.call(picked, function (f) {
return f.arrayBuffer().then(function (b) { return { name: '/www/' + f.name, u8: new Uint8Array(b) }; });
})).then(function (files) {
return confirmUpload(files).then(function (yes) { if (yes) return usbUploadAll(files); });
});
});
function gzipBytes(u8) {
return new Response(new Blob([u8]).stream().pipeThrough(new CompressionStream('gzip'))).arrayBuffer().then(function (b) { return new Uint8Array(b); });
}
$('usbFilesSelfBtn').addEventListener('click', function () {
var msg = $('usbFilesMsg');
if (typeof CompressionStream === 'undefined') { msg.textContent = 'This browser can’t compress files. Use Chrome or Edge, or choose the .gz files instead.'; msg.className = 'status error'; return; }
var names = ['index.html', 'app.js', 'style.css', 'logo.svg'];
Promise.all(names.map(function (n) {
return fetch(n, { cache: 'no-store' }).then(function (r) {
if (!r.ok) throw new Error(n + ' not found');
return r.arrayBuffer();
}).then(function (b) { return gzipBytes(new Uint8Array(b)); }).then(function (u8) { return { name: '/www/' + n + '.gz', u8: u8 }; });
})).then(function (files) {
return confirmUpload(files).then(function (yes) { if (yes) return usbUploadAll(files); });
}).catch(function () {
msg.textContent = 'Couldn’t read this page’s files. Open the page with the local server (python -m http.server --directory www_src), or choose the .gz files.';
msg.className = 'status error';
});
});
$('recalBtn').addEventListener('click', function () {
askConfirm('Re-zero the magnet sensors?', 'Remove any magnets from both sensors first. This takes a moment.', 'Re-zero').then(function (yes) {
if (!yes) return;
busy = true;
post('/recalmag').then(function (r) {
var warn = [];
if (r.noise) {
if (Math.max(r.noise[0], r.noise[1]) > 12) warn.push('The idle signal is noisy (±' + Math.max(r.noise[0], r.noise[1]).toFixed(0) + ' counts): check the sensor wiring and supply.');
if (Math.max(Math.abs(r.zero[0] - 2048), Math.abs(r.zero[1] - 2048)) > 400) warn.push('A baseline this far from the middle usually means a magnet is still near a sensor.');
}
liveStat = newStat();
if (!r.noise) { recalSay('Magnet sensors re-zeroed.', 'ok'); return; }   // older firmware: no measurements in the reply
recalSay('Re-zeroed. Baseline M1 ' + r.zero[0] + ' (±' + r.noise[0].toFixed(1) + '), M2 ' + r.zero[1] + ' (±' + r.noise[1].toFixed(1) + '). ' + warn.join(' '), warn.length ? 'bad' : 'ok');
})
.catch(function (e) { recalSay(e.message, 'bad'); })
.then(function () { busy = false; });
});
});
$('channel').addEventListener('change', function () {
post('/setchannel', { ch: $('channel').value }).then(function () { say('Update channel saved.', 'ok'); })
.catch(function (e) { say(e.message, 'bad'); });
});
$('portalBtn').addEventListener('click', function () {
if (usb) { say('The update portal needs Wi-Fi, not the USB cable.', 'bad'); return; }
askConfirm('Open the update portal?', 'The device leaves this network and opens a setup page. You’ll have to join its Wi-Fi again afterwards.', 'Open portal').then(function (yes) {
if (!yes) return;
busy = true;
post('/enterportal').then(function (r) {
polling = false;
setConn('bad', 'portal');
say('Update portal starting. Join “' + r.name + '” again and open 192.168.4.1.', 'ok');
}).catch(function (e) { busy = false; say(e.message, 'bad'); });
});
});
function installFirmware(f) {
busy = true;
$('fwBtn').disabled = true;
$('fwMeter').classList.remove('hidden');
$('fwMsg').textContent = 'Uploading… keep this tab open.';
var fd = new FormData();
fd.append('firmware', f, f.name);
var x = new XMLHttpRequest();
x.open('POST', '/update?size=' + f.size);
x.setRequestHeader('X-Auth-Token', pin);
x.upload.onprogress = function (e) { if (e.lengthComputable) $('fwBar').style.width = (e.loaded * 100 / e.total) + '%'; };
x.onload = function () {
if (x.status === 200) {
$('fwMsg').textContent = 'Installed. The device is restarting; this page reloads when it’s back.';
setConn('bad', 'restarting');
var tries = 0;
(function wait() {
fetch('/deviceid', { cache: 'no-store' }).then(function () { location.reload(); })
.catch(function () { if (++tries < 40) setTimeout(wait, 1500); });
})();
} else {
var msg = 'Upload failed.';
try { msg = JSON.parse(x.responseText).error || msg; } catch (e) {}
$('fwMsg').textContent = msg;
busy = false; $('fwBtn').disabled = false;
}
};
x.onerror = function () { $('fwMsg').textContent = 'Connection lost during upload.'; busy = false; $('fwBtn').disabled = false; };
x.send(fd);
}
$('fwBtn').addEventListener('click', function () {
if (usb) { $('fwMsg').textContent = 'Firmware upload needs Wi-Fi, not the USB cable.'; return; }
var f = $('fwFile').files[0];
if (!f) { $('fwMsg').textContent = 'Choose a .bin file first.'; return; }
if (!/\.bin$/i.test(f.name)) { $('fwMsg').textContent = 'That doesn’t look like a firmware .bin.'; return; }
askConfirm('Install ' + f.name + '?', Math.round(f.size / 1024) + ' kB. The device restarts afterwards.', 'Install').then(function (yes) { if (yes) installFirmware(f); });
});
var rec = { on: false, stopping: false, s: null, timer: 0, next: 0, fails: 0, t0: 0, seqSnap: null, carry: new Uint8Array(0), last: [0, 0, 0, 0] };
var sheet = { id: 0, s: null, rec: null };
var PANELS = [
{ h: 0.5,  lines: [['rpm', '--c-rpm']], names: ['RPM'], zero: true },
{ h: 0.25, lines: [['temp', '--c-temp']], names: ['Temp °C'] },
{ h: 0.25, lines: [['m1', '--good'], ['m2', '--c-m2']], names: ['M1', 'M2'], sym: true }
];
function cssVar(n) { return getComputedStyle(document.documentElement).getPropertyValue(n).trim(); }
function setLogMsg(text, cls) {
['logMsg', 'logMsg2'].forEach(function (id) { var m = $(id); m.textContent = text || ''; m.className = 'status ' + (cls === 'bad' ? 'error' : ''); });
}
function mag(g) { return g === 0 ? '–' : (g > 0 ? 'N' : 'S') + Math.abs(g); }
function fmtT(sec) {
if (sec < 60) return sec.toFixed(sec < 10 ? 1 : 0) + ' s';
var m = Math.floor(sec / 60), r = Math.round(sec - m * 60);
return m + ':' + (r < 10 ? '0' : '') + r;
}
function niceCeil(v) {
if (v <= 0) return 1;
var p = Math.pow(10, Math.floor(Math.log(v) / Math.LN10)), f = v / p, steps = [1, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10];
for (var i = 0; i < steps.length; i++) if (f <= steps[i] + 1e-9) return steps[i] * p;
return 10 * p;
}
function newSeries(ms) { return { ms: ms, n: 0, rpm: [], temp: [], m1: [], m2: [] }; }
function appendSamples(s, buf) {
var dv = new DataView(buf), k = Math.floor(buf.byteLength / 8);
for (var i = 0; i < k; i++) {
var o = i * 8;
s.rpm.push(dv.getUint16(o, true));
s.temp.push(dv.getInt16(o + 2, true) / 10);
s.m1.push(dv.getInt16(o + 4, true));
s.m2.push(dv.getInt16(o + 6, true));
}
s.n += k;
}
function drawChart(cv, s, cur, minSpanSec) {
var W = cv.clientWidth, H = cv.clientHeight;
if (!W || !H) return;
var dpr = window.devicePixelRatio || 1;
if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); }
var c = cv.getContext('2d');
c.setTransform(dpr, 0, 0, dpr, 0, 0);
c.clearRect(0, 0, W, H);
var grid = cssVar('--border'), dim = cssVar('--text-dim');
var L = 46, R = 8, T = 6, B = 18, gap = 8;
var pw = W - L - R, ph = H - T - B - gap * (PANELS.length - 1);
var span = Math.max(s.n - 1, Math.round(minSpanSec * 1000 / s.ms), 1);
cv._lay = { L: L, pw: pw, span: span };
c.font = '11px system-ui, sans-serif';
c.lineJoin = 'round';
var y0 = T;
PANELS.forEach(function (p) {
var h = ph * p.h, lo = Infinity, hi = -Infinity, i;
p.lines.forEach(function (l) { var a = s[l[0]]; for (i = 0; i < s.n; i++) { if (a[i] < lo) lo = a[i]; if (a[i] > hi) hi = a[i]; } });
if (!s.n) { lo = 0; hi = 1; }
if (p.zero) { lo = 0; hi = niceCeil(hi); }
else if (p.sym) { var m = Math.max(50, niceCeil(Math.max(Math.abs(lo), Math.abs(hi)))); lo = -m; hi = m; }
else { var pad = Math.max(1, (hi - lo) * 0.15); lo = Math.floor(lo - pad); hi = Math.ceil(hi + pad); }
var yOf = function (v) { return y0 + h - (v - lo) / (hi - lo) * h; };
c.strokeStyle = grid; c.fillStyle = dim; c.lineWidth = 1; c.textAlign = 'right'; c.textBaseline = 'middle';
[lo, (lo + hi) / 2, hi].forEach(function (v) {
var y = Math.round(yOf(v)) + 0.5;
c.beginPath(); c.moveTo(L, y); c.lineTo(L + pw, y); c.stroke();
c.fillText(Math.abs(v) >= 1000 ? (v / 1000).toFixed(v % 1000 ? 1 : 0) + 'k' : String(Math.round(v * 10) / 10), L - 6, Math.min(Math.max(y, y0 + 6), y0 + h - 6));
});
p.lines.forEach(function (l) {
var a = s[l[0]];
c.strokeStyle = cssVar(l[1]); c.lineWidth = 1.5;
c.beginPath();
if (s.n > pw * 2) {
var bucket = Math.ceil(s.n / pw), j, bl, bh, bx;
for (var b0 = 0; b0 < s.n; b0 += bucket) {
bl = Infinity; bh = -Infinity;
for (j = b0; j < Math.min(s.n, b0 + bucket); j++) { if (a[j] < bl) bl = a[j]; if (a[j] > bh) bh = a[j]; }
bx = L + pw * b0 / span;
c.moveTo(bx, yOf(bl)); c.lineTo(bx, yOf(bh));
}
} else {
for (i = 0; i < s.n; i++) {
var x = L + pw * i / span, y = yOf(a[i]);
if (i) c.lineTo(x, y); else c.moveTo(x, y);
}
}
c.stroke();
});
c.textAlign = 'left'; c.textBaseline = 'top';
var lx = L + 6;
p.names.forEach(function (nm, k) {
c.fillStyle = cssVar(p.lines[k][1]);
c.fillText(nm, lx, y0 + 3);
lx += c.measureText(nm).width + 10;
});
if (p.sym) { c.fillStyle = dim; c.fillText('gauss, N + / S −', lx, y0 + 3); }
y0 += h + gap;
});
c.fillStyle = dim; c.textBaseline = 'alphabetic';
[0, 0.5, 1].forEach(function (f, k) {
c.textAlign = k === 0 ? 'left' : (k === 2 ? 'right' : 'center');
c.fillText(fmtT(span * f * s.ms / 1000), L + pw * f, H - 4);
});
if (cur !== null && cur >= 0 && cur < s.n) {
var cx = Math.round(L + pw * cur / span) + 0.5;
c.strokeStyle = dim; c.lineWidth = 1;
c.beginPath(); c.moveTo(cx, T); c.lineTo(cx, H - B); c.stroke();
}
}
function summarize(s) {
var st = newStat(), peakAt = 0, i;
for (i = 0; i < s.n; i++) {
var before = st.rMax;
addStat(st, s.rpm[i], s.temp[i], s.m1[i], s.m2[i]);
if (st.rMax > before) peakAt = i;
}
st.peakAt = peakAt;
st.tRise = s.n ? s.temp[s.n - 1] - s.temp[0] : 0;
return st;
}
var dbp = null;
function idb() {
if (!dbp) dbp = new Promise(function (res, rej) {
if (!window.indexedDB) { rej(new Error('This browser has no storage for runs.')); return; }
var q = indexedDB.open('motorstand', 1);
q.onupgradeneeded = function () {
q.result.createObjectStore('runs', { keyPath: 'id', autoIncrement: true });
};
q.onsuccess = function () { res(q.result); };
q.onerror = function () { rej(new Error('This browser is blocking storage; try a normal (non-private) tab.')); };
});
return dbp;
}
function tx(store, mode, fn) {
return idb().then(function (db) {
return new Promise(function (res, rej) {
var t = db.transaction(store, mode), r = fn(t.objectStore(store));
t.oncomplete = function () { res(r && r.result); };
t.onerror = t.onabort = function () { rej(t.error || new Error('Storage error')); };
});
});
}
function packSeries(s) {
var b = new ArrayBuffer(s.n * 8), dv = new DataView(b);
for (var i = 0; i < s.n; i++) {
var o = i * 8;
dv.setUint16(o, s.rpm[i], true);
dv.setInt16(o + 2, Math.round(s.temp[i] * 10), true);
dv.setInt16(o + 4, s.m1[i], true);
dv.setInt16(o + 6, s.m2[i], true);
}
return b;
}
function seriesOf(r) { var s = newSeries(r.ms); appendSamples(s, r.buf); return s; }
function fmtStamp(t) {
var d = new Date(t);
return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) +
', ' + d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
}
var MAX_SAMPLES = 400000;       // 11 hours at 10 a second; the device's own storage limit normally comes first
function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
function lsDel(k) { try { localStorage.removeItem(k); } catch (e) {} }
function recKey() { return 'ms.rec.' + deviceKey; }
function recSeqKey() { return 'ms.recseq.' + deviceKey; }     // the sequence the running recording was started with          // when the running recording started
function stopKey() { return 'ms.stop.' + deviceKey; }        // set while the device still has to be told to stop
function renderRec() {
var btn = $('logBtn');
btn.textContent = rec.on ? 'Stop and save' : 'Start recording';
btn.className = 'btn ' + (rec.on ? 'danger' : 'primary');
$('logRate').disabled = rec.on;
$('logCap').classList.toggle('hidden', rec.on);
$('rateStatus').textContent = rec.on ? 'A recording is running: the rate can be changed once it stops.' : 'The rate applies to the next recording. It can’t be changed while one is running.';
$('recBar').classList.toggle('hidden', !rec.on);
$('liveChart').classList.toggle('hidden', !rec.on);
updateRecSeq();
if (!rec.on) return;
var s = rec.s, last = s.n - 1;
$('recText').textContent = (rec.fails > 1 ? 'Connection lost, retrying… ' : 'Recording ') + fmtT(s.n * s.ms / 1000) + ' · ' + s.n + ' samples' +
(s.n && !rec.fails ? ' · ' + s.rpm[last].toLocaleString() + ' rpm' : '');
$('liveChart').setAttribute('aria-label', 'Recording graph: speed, temperature and magnets, ' + fmtT(s.n * s.ms / 1000) + ' so far');
drawChart($('liveChart'), s, null, 5);
}
function updateCapacity() {
if (rec.on) return;
api('/logstate').then(function (st) {
if (rec.on || st.armed) return;
var ms = Number($('logRate').value), t;
capFree = st.free;
renderRateGuide();
if (st.free < 8192) t = 'Not enough free space on the device to record.';
else t = 'Space for about ' + hoursFor(3, ms) + ' at this rate, or ' + hoursFor(7, ms) + ' if the motor and magnets are very busy.';
$('logCap').textContent = t;
}).catch(function () { $('logCap').textContent = ''; });
}
var RATES = [
{ ms: 100, name: '10 per second', note: 'Reading for reading what the live graph shows' },
{ ms: 200, name: '5 per second', note: 'The default: fast enough for quick changes' },
{ ms: 500, name: '2 per second', note: 'Smooth trends, quick changes between readings are missed' },
{ ms: 1000, name: '1 per second', note: 'The longest recordings; the coarsest' }
];
var capFree = null;                 // bytes the stand reports free for a recording, once known
function rateName(ms) { var r = RATES.filter(function (x) { return x.ms === ms; })[0]; return r ? r.name : ''; }
function hoursFor(bytesPerSample, ms) {
var h = capFree / (bytesPerSample * (1000 / ms)) / 3600;
return h >= 1 ? h.toFixed(1) + ' h' : Math.floor(h * 60) + ' min';
}
function renderRateGuide() {
var cur = Number($('logRate').value), ul = $('rateGuide');
ul.innerHTML = '';
RATES.forEach(function (r) {
var li = el('li', r.ms === cur ? 'current' : '');
var left = el('div');
left.appendChild(el('b', '', r.name));
left.appendChild(el('div', '', r.note));
li.appendChild(left);
li.appendChild(el('span', 'hours', capFree === null ? '' : hoursFor(3, r.ms) + ' typical · ' + hoursFor(7, r.ms) + ' busy'));
ul.appendChild(li);
});
$('rateLink').textContent = 'Sample rate: ' + rateName(cur) + ' · Change';
$('logRate').disabled = rec.on;
}
(function initRate() {
var saved = Number(lsGet('ms.rate'));
$('logRate').value = rateName(saved) ? String(saved) : '200';
renderRateGuide();
})();
$('logRate').addEventListener('change', function () { lsSet('ms.rate', $('logRate').value); renderRateGuide(); updateCapacity(); });
$('rateLink').addEventListener('click', function () {
if (layerStack.indexOf('settings') < 0) openSettings();
$('recordingGroup').scrollIntoView();
});
$('logSeq').addEventListener('change', function () { seq.bind = $('logSeq').value; seqSave(); $('recSeq').textContent = recSeqText(); });
function decodeLog(s, last, bytes) {
var i = 0, n = bytes.length;
while (i < n) {
var tag = bytes[i];
if (tag === 0x80) {
if (i + 9 > n) break;
last[0] = bytes[i + 1] | (bytes[i + 2] << 8);
last[1] = ((bytes[i + 3] | (bytes[i + 4] << 8)) << 16) >> 16;
last[2] = ((bytes[i + 5] | (bytes[i + 6] << 8)) << 16) >> 16;
last[3] = ((bytes[i + 7] | (bytes[i + 8] << 8)) << 16) >> 16;
i += 9;
} else if (tag < 0x10) {
var j = i + 1, d = [0, 0, 0, 0], k, b, z, shift, whole = true;
for (k = 0; k < 4 && whole; k++) {
if (!(tag & (1 << k))) continue;
z = 0; shift = 0;
for (;;) {
if (j >= n) { whole = false; break; }
b = bytes[j++];
z |= (b & 0x7F) << shift;
if (!(b & 0x80) || shift > 21) break;
shift += 7;
}
d[k] = (z >>> 1) ^ -(z & 1);
}
if (!whole) break;
for (k = 0; k < 4; k++) last[k] += d[k];
i = j;
} else { i++; continue; }              // not the start of a record: skip a damaged byte
s.rpm.push(last[0]); s.temp.push(last[1] / 10); s.m1.push(last[2]); s.m2.push(last[3]); s.n++;
}
return i;
}
function takeBytes(buffer) {
var inc = new Uint8Array(buffer), data = inc;
if (rec.carry.length) { data = new Uint8Array(rec.carry.length + inc.length); data.set(rec.carry); data.set(inc, rec.carry.length); }
var used = decodeLog(rec.s, rec.last, data);
rec.carry = data.slice(used);
rec.next += inc.length;               // bytes received: where the next pull starts
}
function drain() {
return raw('/logdata?from=' + rec.next).then(function (r) {
var next = Number(r.headers.get('X-Next'));
return r.arrayBuffer().then(function (b) {
takeBytes(b);
if (b.byteLength && rec.next < next) return drain();
});
});
}
function logPoll() {
clearTimeout(rec.timer);
if (!rec.on || rec.stopping) return;
raw('/logdata?from=' + rec.next).then(function (r) {
var next = Number(r.headers.get('X-Next')), armed = r.headers.get('X-Armed') === '1', full = r.headers.get('X-Full') === '1';
return r.arrayBuffer().then(function (b) {
if (!rec.on || rec.stopping) return;
rec.fails = 0;
if (!armed || next < rec.next) { finishRecording('The device restarted, so the run was saved up to that point.'); return; }
takeBytes(b);
renderRec();
if (rec.s.n >= MAX_SAMPLES) finishRecording('Reached the sample limit, so the run was saved.');
else if (rec.next < next && b.byteLength) rec.timer = setTimeout(logPoll, 20);
else if (full) finishRecording('The device ran out of room, so the run was saved.');
else rec.timer = setTimeout(logPoll, 500);
});
}).catch(function (err) {
if (!rec.on || rec.stopping) return;
rec.fails++;
renderRec();
rec.timer = setTimeout(logPoll, 1500);
});
}
function beginPulling(ms, t0) {
rec.s = newSeries(ms);
rec.next = 0; rec.fails = 0; rec.stopping = false; rec.t0 = t0;
rec.carry = new Uint8Array(0); rec.last = [0, 0, 0, 0];
rec.on = true;
try { rec.seqSnap = JSON.parse(lsGet(recSeqKey()) || 'null'); } catch (e) { rec.seqSnap = null; }
lsSet(recKey(), String(t0));
renderRec();
logPoll();
}
function startRecording() {
var btn = $('logBtn');
btn.disabled = true;
idb().then(function () { return post('/logstart', { ms: $('logRate').value }); }).then(function (r) {
var bound = seqBound(), snap = null;
if (bound) { snap = Object.assign({}, bound); delete snap.id; delete snap.c; delete snap.t; delete snap.auto; }
lsSet(recSeqKey(), JSON.stringify(snap));
setLogMsg('');
beginPulling(r.ms, Date.now());
}).catch(function (e) { if (e.code !== 401) setLogMsg(e.message, 'bad'); }).then(function () { btn.disabled = false; });
}
function stopDevice() {
lsSet(stopKey(), '1');
return post('/logstop').then(function () { lsDel(stopKey()); }).catch(function () {});
}
function finishRecording(msg) {
var s = rec.s, t0 = rec.t0;
clearTimeout(rec.timer);
rec.on = false;
rec.stopping = false;
lsDel(recKey());
var snapUsed = rec.seqSnap;
lsDel(recSeqKey());
rec.seqSnap = null;
renderRec();
if (!s || !s.n) { stopDevice(); setLogMsg('Nothing was recorded.', 'bad'); return Promise.resolve(); }
var record = { deviceKey: deviceKey, t: t0, ms: s.ms, note: '', seq: snapUsed || null, buf: packSeries(s) };
return tx('runs', 'readwrite', function (st) { return st.add(record); }).then(function (id) {
stopDevice().then(function () { updateCapacity(); });
setLogMsg(msg || '');
loadRuns();
showRun(id);
}).catch(function (e) { setLogMsg('Couldn’t save the run: ' + e.message + ' The device still has the data.', 'bad'); });
}
function stopRecording() {
var btn = $('logBtn');
btn.disabled = true;
rec.stopping = true;
clearTimeout(rec.timer);
drain().then(function () { return null; }, function () { return 'Couldn’t reach the device for the last readings, so the run ends at the last one received.'; })
.then(function (msg) { return finishRecording(msg); })
.then(function () { btn.disabled = false; });
}
$('logBtn').addEventListener('click', function () { if (rec.on) stopRecording(); else startRecording(); });
function el(tag, cls, text) {
var e = document.createElement(tag);
if (cls) e.className = cls;
if (text !== undefined) e.textContent = text;
return e;
}
function loadRuns() {
return tx('runs', 'readonly', function (st) { return st.getAll(); }).then(function (all) {
var runs = all.filter(function (r) { return r.deviceKey === deviceKey; }).sort(function (a, b) { return b.id - a.id; });
$('logFree').textContent = runs.length ? runs.length + ' on this phone' : '';
$('runEmpty').classList.toggle('hidden', runs.length > 0);
$('delRunsHint').textContent = runs.length ? runs.length + (runs.length === 1 ? ' run' : ' runs') + ' saved on this phone' : 'Nothing saved yet';
$('deleteAllBtn').disabled = !runs.length;
var ul = $('runList');
ul.innerHTML = '';
runs.forEach(function (r) {
var b = el('button', 'runRow');
b.type = 'button';
b.appendChild(el('span', 'rid', '#' + r.id));
var main = el('div', 'main');
main.appendChild(el('b', '', fmtT(r.buf.byteLength / 8 * r.ms / 1000) + ' · ' + Math.round(1000 / r.ms * 10) / 10 + '/s'));
main.appendChild(el('span', '', [fmtStamp(r.t), r.note].filter(Boolean).join(' · ')));
b.appendChild(main);
b.addEventListener('click', function () { showRun(r.id); });
var li = el('li');
li.appendChild(b);
ul.appendChild(li);
});
}).catch(function (e) { setLogMsg(e.message, 'bad'); });
}
function showRun(id) {
return tx('runs', 'readonly', function (st) { return st.get(id); }).then(function (r) {
if (!r) throw new Error('That run is gone.');
sheet.id = id;
sheet.rec = r;
var s = sheet.s = seriesOf(r), st = summarize(s);
$('sheetTitle').textContent = 'Run #' + id;
var rows = (r.seq ? [['Sequence', r.seq.name], ['Settings', seqSettings(Object.assign({}, SEQ_DEFAULT, r.seq))]] : []).concat([
['Duration', fmtT(s.n * s.ms / 1000)],
['Peak speed', fmtRpm(st.rMax) + ' rpm'],
['Slowest while spinning', fmtRpm(st.rMin) + ' rpm'],
['Average speed', st.n ? fmtRpm(st.sum / st.n) + ' rpm' : '–'],
['Peak at', fmtT(st.peakAt * s.ms / 1000)],
['Max temperature', fmtC(st.tMax)],
['Min temperature', fmtC(st.tMin)],
['Temperature change', (st.tRise >= 0 ? '+' : '') + st.tRise.toFixed(1) + ' °C'],
['Magnet 1 north', magRange(st.m[0].nMin, st.m[0].nMax)],
['Magnet 1 south', magRange(st.m[0].sMin, st.m[0].sMax)],
['Magnet 2 north', magRange(st.m[1].nMin, st.m[1].nMax)],
['Magnet 2 south', magRange(st.m[1].sMin, st.m[1].sMax)]
]);
var dl = $('sheetStats');
dl.innerHTML = '';
rows.forEach(function (row) {
var d = el('div');
d.appendChild(el('dt', '', row[0]));
d.appendChild(el('dd', '', row[1]));
dl.appendChild(d);
});
$('runNote').value = r.note || '';
noteSummary();
$('runNoteBox').open = false;
$('runReadout').textContent = fmtStamp(r.t) + '. Touch or drag across the graph to read values.';
$('sheet').classList.remove('hidden');
if (layerStack.indexOf('sheet') < 0) pushLayer('sheet', closeSheetDom);
$('runChart').setAttribute('aria-label', 'Run graph: speed, temperature and magnets over ' + fmtT(s.n * s.ms / 1000));
drawChart($('runChart'), s, null, 0);
}).catch(function (e) { setLogMsg('Couldn’t open run #' + id + ': ' + e.message, 'bad'); });
}
function closeSheetDom() {
if (noteTimer) saveNote();
$('sheet').classList.add('hidden');
sheet.s = null; sheet.rec = null;
}
function closeSheet() { dismissLayer('sheet'); }
$('sheetClose').addEventListener('click', closeSheet);
$('sheetBackdrop').addEventListener('click', closeSheet);
function runShareText(id, r) {
var s = seriesOf(r), st = summarize(s), lines = ['Motor Checker run #' + id + ' (' + fmtStamp(r.t) + ')'];
if (r.seq) lines.push('Sequence: ' + r.seq.name + ' · ' + seqSettings(Object.assign({}, SEQ_DEFAULT, r.seq)));
lines.push('Duration: ' + fmtT(s.n * s.ms / 1000), 'Peak speed: ' + fmtRpm(st.rMax) + ' rpm', 'Average speed: ' + (st.n ? fmtRpm(st.sum / st.n) : '–') + ' rpm',
'Temperature: ' + fmtC(st.tMin) + ' to ' + fmtC(st.tMax));
if (r.note) lines.push('Note: ' + r.note);
return lines.join('\n');
}
$('shareRunBtn').addEventListener('click', function () { if (sheet.rec) shareText('Motor Checker run #' + sheet.id, runShareText(sheet.id, sheet.rec)); });
function scrub(ev) {
var cv = $('runChart'), s = sheet.s;
if (!s || !cv._lay || !s.n) return;
var lay = cv._lay, x = ev.clientX - cv.getBoundingClientRect().left;
var i = Math.max(0, Math.min(s.n - 1, Math.round((x - lay.L) / lay.pw * lay.span)));
drawChart(cv, s, i, 0);
$('runReadout').textContent = fmtT(i * s.ms / 1000) + ' · ' + s.rpm[i].toLocaleString() + ' rpm · ' + s.temp[i].toFixed(1) +
' °C · M1 ' + mag(s.m1[i]) + ' · M2 ' + mag(s.m2[i]);
}
$('runChart').addEventListener('pointerdown', scrub);
$('runChart').addEventListener('pointermove', scrub);
function noteSummary() {
var t = $('runNote').value.trim().split('\n')[0];
$('runNoteSummary').textContent = t || 'Add a note…';
$('runNoteSummary').classList.toggle('has', !!t);
}
var noteTimer = 0;
function saveNote() {
clearTimeout(noteTimer);
noteTimer = 0;
var r = sheet.rec;
if (!r) return;
r.note = $('runNote').value;
tx('runs', 'readwrite', function (st) { return st.put(r); }).then(loadRuns).catch(function (e) { $('runReadout').textContent = e.message; });
}
$('runNote').addEventListener('input', function () { noteSummary(); clearTimeout(noteTimer); noteTimer = setTimeout(saveNote, 500); });
var CSV_HEAD = 'Run,Sample,TimeS,RPM,TempC,Mag1Gauss,Mag2Gauss,Note,RecordedOnPhone,Sequence,SequenceDetails';
function csvLines(id, r) {
var s = seriesOf(r), d = new Date(r.t), rows = [];
var p = function (n) { return String(n).padStart(2, '0'); };
var stamp = d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
for (var i = 0; i < s.n; i++) {
rows.push([id, i, (i * s.ms / 1000).toFixed(3), s.rpm[i], s.temp[i].toFixed(1), s.m1[i], s.m2[i],
i ? '' : csvQuote(r.note), i ? '' : stamp,
i || !r.seq ? '' : csvQuote(r.seq.name), i || !r.seq ? '' : csvQuote(seqSettings(Object.assign({}, SEQ_DEFAULT, r.seq)))].join(','));
}
return rows;
}
function myRuns() {
return tx('runs', 'readonly', function (st) { return st.getAll(); }).then(function (all) {
return all.filter(function (r) { return r.deviceKey === deviceKey; }).sort(function (a, b) { return a.id - b.id; });
});
}
$('csvBtn').addEventListener('click', function () {
if (!sheet.s) return;
var lines = csvLines(sheet.id, sheet.rec);
downloadCsv('motorchecker_run_' + sheet.id + '.csv', [CSV_HEAD].concat(lines).join('\n') + '\n', { count: lines.length, one: 'sample', many: 'samples' });
});
$('exportAllBtn').addEventListener('click', function () {
myRuns().then(function (runs) {
if (!runs.length) { showNotice('Nothing to export yet.', 'error'); return; }
var rows = [CSV_HEAD];
runs.forEach(function (r) { rows = rows.concat(csvLines(r.id, r)); });
downloadCsv('motorchecker_all_runs.csv', rows.join('\n') + '\n', { count: runs.length, one: 'run', many: 'runs' });
}).catch(function (e) { setLogMsg(e.message, 'bad'); });
});
$('deleteAllBtn').addEventListener('click', function () {
myRuns().then(function (runs) {
if (!runs.length) return;
return askConfirm('Delete all saved runs?', runs.length + (runs.length === 1 ? ' run' : ' runs') + ' will be removed from this phone. Export them first if you want to keep them.', 'Delete all').then(function (yes) {
if (!yes) return;
return tx('runs', 'readwrite', function (st) { runs.forEach(function (r) { st.delete(r.id); }); }).then(loadRuns).then(function () {
settingStatus('dataActionStatus', 'All saved runs were deleted.', 'ok');
});
});
}).catch(function (e) { settingStatus('dataActionStatus', e.message, 'error'); });
});
$('delBtn').addEventListener('click', function () {
var id = sheet.id;
askConfirm('Delete run #' + id + '?', 'It is removed from this phone. Export it first if you want to keep it.', 'Delete').then(function (yes) {
if (!yes) return;
return tx('runs', 'readwrite', function (st) { return st.delete(id); }).then(function () {
sheet.rec = null;
closeSheet();
loadRuns();
showNotice('Run #' + id + ' deleted.', 'ok');
});
}).catch(function (e) { $('runReadout').textContent = e.message; });
});
window.addEventListener('resize', function () {
drawLiveAll();
if (rec.on) drawChart($('liveChart'), rec.s, null, 5);
if (sheet.s) drawChart($('runChart'), sheet.s, null, 0);
});
function logInit() {
if (rec.on) return;
var pending = lsGet(stopKey()) === '1' ? stopDevice() : Promise.resolve();
pending.then(function () {
if (lsGet(stopKey()) === '1') { setLogMsg('The last run is saved, but the device couldn’t be told to stop recording. It stops when the device restarts.', 'bad'); return; }
return api('/logstate').then(function (st) {
if (!st.armed) { lsDel(recKey()); return; }
setLogMsg('The device kept recording while this page was away. Catching up…');
beginPulling(st.ms, Number(lsGet(recKey())) || (Date.now() - st.count * st.ms));
});
}).catch(function () {}).then(function () { loadRuns(); updateCapacity(); });
}
var SEQ_KEY = 'ms.seq';
var MOTOR_TYPES = ['Torque Tuned', 'Atomic Tuned', 'Rev Tuned', 'Light Dash', 'Hyper Dash', 'Power Dash', 'Sprint Dash', 'Ultra Dash',
'Torque Tuned Pro', 'Atomic Tuned Pro', 'Rev Tuned Pro', 'Light Dash Pro', 'Hyper Dash Pro', 'Mach Dash Pro', 'Custom'];
var SEQ_DEFAULT = { name: 'Sequence 1', motor: 'Torque Tuned', motorCustom: '', volt: 3, ilim: 2, dir: 'AUTO', timer: 30, swing: false, maxv: 4.2, period: 20, wave: 'SINE', note: '' };
var SEQ_DIRS = ['AUTO', 'FORWARD', 'REVERSE'];
var SEQ_WAVES = ['SINE', 'TRIANGLE', 'TRAPEZOID'];
var SEQ_STEPS = [
['volt', 0.5, 6, 0.1, 1, 1], ['ilim', 0.1, 2, 0.1, 0.5, 1], ['timer', 1, 300, 1, 10, 0],
['maxv', 0.5, 6, 0.1, 1, 1], ['period', 1, 60, 0.1, 5, 1]
];
var seq = { id: '', list: [], del: {} };   // items carry id (string), c (created ms), t (last edited ms); auto = untouched starter
var seqInputs = {};
function seqNewId() { return 'q' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
function seqMake(over) {
var now = Date.now(), o = Object.assign({}, SEQ_DEFAULT, over || {}, { id: seqNewId(), c: now, t: now });
delete o.auto;
return o;
}
function seqCur() { return seq.list.filter(function (x) { return x.id === seq.id; })[0]; }
function seqBound() { return seq.bind ? seq.list.filter(function (x) { return x.id === seq.bind; })[0] || null : null; }
function seqSave() { lsSet(SEQ_KEY, JSON.stringify(seq)); }
function motorLabel(c) { return c.motor === 'Custom' && c.motorCustom ? c.motorCustom : c.motor; }
function seqSettings(c) {
return motorLabel(c) + ' · ' + c.volt.toFixed(1) + ' V · ' + c.ilim.toFixed(1) + ' A · ' + c.dir + ' · ' + c.timer + ' min' +
(c.swing ? ' · swing ' + c.period.toFixed(1) + ' s ' + c.wave + ' to ' + c.maxv.toFixed(1) + ' V' : '');
}
function csvQuote(t) { return '"' + String(t || '').replace(/"/g, '""') + '"'; }
function seqLoad() {
var j = null;
try { j = JSON.parse(lsGet(SEQ_KEY) || 'null'); } catch (e) {}
if (j && j.list && j.list.length) {
var idMap = {};
seq.list = j.list.map(function (x) {
var y = Object.assign({}, SEQ_DEFAULT, x);
if (typeof y.id !== 'string') { var nid = seqNewId(); idMap[x.id] = nid; y.id = nid; }   // older numeric ids
y.c = y.c || Date.now();
y.t = y.t || y.c;
return y;
});
seq.del = j.del || {};
seq.id = typeof j.id === 'string' ? j.id : (idMap[j.id] || seq.list[0].id);
if (!seq.list.some(function (x) { return x.id === seq.id; })) seq.id = seq.list[0].id;
seq.bind = typeof j.bind === 'string' ? j.bind : seq.id;   // before this existed, recordings used the selected sequence
} else {
var first = seqMake();
first.auto = true;
seq = { id: first.id, list: [first], del: {}, bind: first.id };
}
}
var sync = { state: 'pending', dirty: false, changedAt: 0, okAt: 0, lastAt: 0, busy: false, unsupported: false };
function syncLineText() {
if (usb) return 'Saved on this phone only. Sequences sync over Wi-Fi, not the USB cable.';
if (sync.state === 'ok' && !sync.dirty) {
var d = new Date(sync.okAt);
return 'Synced to the device at ' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0') + '.';
}
if (sync.state === 'fail') return 'Saved on this phone only. Couldn’t reach the device to sync; trying again.';
if (sync.state === 'old') return 'Saved on this phone only. Update the device firmware to sync sequences.';
if (sync.state === 'big') return 'Saved on this phone only. Your sequences are too large to sync.';
return 'Syncing to the device…';
}
function renderSyncLine() {
var el1 = $('seqSync');
el1.textContent = syncLineText();
el1.classList.toggle('error', !usb && (sync.state === 'fail' || sync.state === 'old' || sync.state === 'big'));
}
function seqDirty() { sync.dirty = true; sync.changedAt = Date.now(); renderSyncLine(); }
function seqTouch(c) { delete c.auto; c.t = Date.now(); seqSave(); seqDirty(); }
function mergeSeq(a, b) {
var del = {}, items = {};
[a, b].forEach(function (d) {
Object.keys(d.del || {}).forEach(function (id) { del[id] = Math.max(del[id] || 0, d.del[id]); });
(d.items || []).forEach(function (x) { if (x && x.id && (!items[x.id] || (x.t || 0) > (items[x.id].t || 0))) items[x.id] = x; });
});
var out = [];
Object.keys(items).forEach(function (id) { if (!(del[id] >= (items[id].t || 0))) out.push(items[id]); });   // a deletion newer than the last edit wins
out.sort(function (p, q) { return (p.c || 0) - (q.c || 0); });
var keys = Object.keys(del).sort(function (p, q) { return del[q] - del[p]; }).slice(0, 100);
var kept = {};
keys.forEach(function (k) { kept[k] = del[k]; });
return { items: out, del: kept };
}
function seqSig(d) {
return (d.items || []).map(function (x) { return x.id + ':' + x.t; }).sort().join('|') + '#' +
Object.keys(d.del || {}).sort().map(function (k) { return k + ':' + d.del[k]; }).join('|');
}
function applyMerged(m) {
var starter = seq.list.filter(function (x) { return x.auto; });
var list = m.items.map(function (x) { return Object.assign({}, SEQ_DEFAULT, x); });
if (!list.length) list = starter.length ? starter : [seqMake()];
seq.list = list;
seq.del = m.del;
if (!list.some(function (x) { return x.id === seq.id; })) seq.id = list[0].id;
seqSave();
seqRender();
}
function syncNow() {
if (sync.busy || !polling || usb || sync.unsupported) return;
sync.busy = true;
sync.state = 'syncing';
sync.lastAt = Date.now();
var sentAt = sync.changedAt;
var local = { items: seq.list.filter(function (x) { return !x.auto; }), del: seq.del };
raw('/phonedata').then(function (r) { return r.json(); }).then(function (remote) {
var theirs = (remote && remote.seq) || {};
var merged = mergeSeq(local, theirs);
applyMerged(merged);
var body = JSON.stringify({ v: 1, seq: merged });
if (body.length > 16000) { sync.state = 'big'; return; }
if (seqSig(theirs) === seqSig(merged)) { sync.state = 'ok'; sync.okAt = Date.now(); if (sync.changedAt <= sentAt) sync.dirty = false; return; }
return raw('/phonedata', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: body }).then(function () {
sync.state = 'ok';
sync.okAt = Date.now();
if (sync.changedAt <= sentAt) sync.dirty = false;
});
}).catch(function (err) {
if (err instanceof SyntaxError) { sync.state = 'old'; sync.unsupported = true; }       // the route doesn't exist: the device answered with its web page
else if (/too large|storage full/.test(err.message)) sync.state = 'big';
else sync.state = 'fail';
}).then(function () { sync.busy = false; renderSyncLine(); });
}
setInterval(function () {
if (!polling || usb || sync.unsupported) return;
var now = Date.now();
if (sync.dirty ? (now - sync.changedAt >= 2000 && now - sync.lastAt >= 2000) : now - sync.lastAt >= 30000) syncNow();
}, 1000);
function chips(box, values, cur, pick) {
box.innerHTML = '';
values.forEach(function (v) {
var b = el('button', 'chip' + (v === cur ? ' selected' : ''), v);
b.type = 'button';
b.setAttribute('aria-pressed', v === cur ? 'true' : 'false');
b.addEventListener('click', function () { pick(v); });
box.appendChild(b);
});
}
function seqSet(key, v) {
var c = seqCur();
c[key] = v;
if (c.swing && c.maxv < c.volt) { if (key === 'maxv') c.volt = c.maxv; else c.maxv = c.volt; }
seqTouch(c);
seqRender();
}
function recSeqText() {
var c = rec.on ? rec.seqSnap : seqBound();
if (!c) return rec.on ? 'Recording without a sequence.' : 'This recording will not be bound to a sequence.';
return (rec.on ? 'Recording with “' : 'Bound to “') + c.name + '”: ' + seqSettings(c);
}
function renderLogSeq() {
var sel = $('logSeq'), want = seq.bind || '';
if (want && !seq.list.some(function (x) { return x.id === want; })) { want = seq.bind = ''; seqSave(); }   // it was deleted
sel.innerHTML = '';
[{ id: '', name: 'No sequence' }].concat(seq.list).forEach(function (x) {
var o = document.createElement('option');
o.value = x.id; o.textContent = x.name;
sel.appendChild(o);
});
sel.value = want;
sel.disabled = rec.on;
}
function updateRecSeq() { renderLogSeq(); $('recSeq').textContent = recSeqText(); }
function seqRender() {
var c = seqCur();
var ul = $('seqList');
ul.innerHTML = '';
seq.list.forEach(function (x) {
var b = el('button', 'setupRow' + (x.id === seq.id ? ' selected' : ''));
b.type = 'button';
b.setAttribute('aria-pressed', x.id === seq.id ? 'true' : 'false');
b.appendChild(el('span', 'setupRowName', x.name));
b.appendChild(el('span', 'setupRowMeta', seqSettings(x)));
b.addEventListener('click', function () { seq.id = x.id; seqSave(); seqRender(); });
var li = el('li');
li.appendChild(b);
ul.appendChild(li);
});
updateRecSeq();
$('seqCount').textContent = seq.list.length > 1 ? seq.list.length + ' saved' : '';
if (document.activeElement !== $('seqName')) $('seqName').value = c.name;
if (document.activeElement !== $('seqNote')) $('seqNote').value = c.note;
if (document.activeElement !== $('seqMotorCustom')) $('seqMotorCustom').value = c.motorCustom;
$('seqMotor').value = c.motor;
$('seqMotorCustomField').classList.toggle('hidden', c.motor !== 'Custom');
SEQ_STEPS.forEach(function (d) {
var inp = seqInputs[d[0]];
if (document.activeElement !== inp) inp.value = c[d[0]].toFixed(d[5]);
});
chips($('seqDir'), SEQ_DIRS, c.dir, function (v) { seqSet('dir', v); });
chips($('seqWave'), SEQ_WAVES, c.wave, function (v) { seqSet('wave', v); });
$('seqSwing').checked = c.swing;
$('seqSwingBox').classList.toggle('hidden', !c.swing);
$('seqDel').textContent = seq.list.length > 1 ? 'Delete' : 'Reset';
$('delSeqHint').textContent = seq.list.length === 1 ? '1 sequence saved' : seq.list.length + ' sequences saved';
renderSyncLine();
updateRecSeq();
}
function seqCsv() {
var rows = ['Sequence,Motor,Voltage_V,CurrentLimit_A,Direction,Timer_min,Swing,MaxVoltage_V,Period_s,Wave,Notes'];
seq.list.forEach(function (c) {
rows.push([csvQuote(c.name), csvQuote(motorLabel(c)), c.volt.toFixed(1), c.ilim.toFixed(1), c.dir, c.timer, c.swing ? 'on' : 'off',
c.swing ? c.maxv.toFixed(1) : '', c.swing ? c.period.toFixed(1) : '', c.swing ? c.wave : '', csvQuote(c.note)].join(','));
});
return rows.join('\n') + '\n';
}
function seqShareText(c) {
var lines = ['Motor Checker sequence: ' + c.name, 'Motor: ' + motorLabel(c), 'Voltage: ' + c.volt.toFixed(1) + ' V', 'Current limit: ' + c.ilim.toFixed(1) + ' A',
'Direction: ' + c.dir, 'Timer: ' + c.timer + ' min'];
if (c.swing) lines.push('Voltage swing: ' + c.period.toFixed(1) + ' s ' + c.wave + ', up to ' + c.maxv.toFixed(1) + ' V');
if (c.note) lines.push('Notes: ' + c.note);
return lines.join('\n');
}
function buildSequence() {
MOTOR_TYPES.forEach(function (n) {
var o = document.createElement('option');
o.value = n; o.textContent = n;
$('seqMotor').appendChild(o);
});
SEQ_STEPS.forEach(function (d) {
var key = d[0], min = d[1], max = d[2], fine = d[3], coarse = d[4], dec = d[5], box = $('sp-' + key);
var put = function (v) {
v = Number(v);
if (isNaN(v)) v = seqCur()[key];
seqSet(key, Number(Math.min(max, Math.max(min, Math.round(v / fine) * fine)).toFixed(dec)));
};
var btn = function (label, delta, isCoarse) {
var b = el('button', 'stepBtn' + (isCoarse ? ' coarse' : ''), label);
b.type = 'button';
b.setAttribute('aria-label', (delta < 0 ? 'Decrease by ' : 'Increase by ') + Math.abs(delta));
b.addEventListener('click', function () { put(seqCur()[key] + delta); });
return b;
};
var inp = document.createElement('input');
inp.type = 'number'; inp.step = 'any'; inp.inputMode = dec ? 'decimal' : 'numeric'; inp.className = 'stepInput';
inp.addEventListener('change', function () { put(inp.value); });
box.appendChild(btn('−' + coarse, -coarse, true));
box.appendChild(btn('−' + fine, -fine, false));
box.appendChild(inp);
box.appendChild(btn('+' + fine, fine, false));
box.appendChild(btn('+' + coarse, coarse, true));
seqInputs[key] = inp;
});
$('seqMotor').addEventListener('change', function () { seqSet('motor', $('seqMotor').value); });
$('seqMotorCustom').addEventListener('input', function () { var c = seqCur(); c.motorCustom = $('seqMotorCustom').value; seqTouch(c); seqRender(); });
$('seqName').addEventListener('input', function () { var c = seqCur(); c.name = $('seqName').value.trim() || 'Sequence'; seqTouch(c); seqRender(); });
$('seqNote').addEventListener('input', function () { var c = seqCur(); c.note = $('seqNote').value; seqTouch(c); });
$('seqSwing').addEventListener('change', function () {
var c = seqCur();
c.swing = $('seqSwing').checked;
if (c.swing && c.maxv < c.volt) c.maxv = c.volt;
seqTouch(c);
seqRender();
});
$('seqNew').addEventListener('click', function () {
var n = seqMake({ name: 'Sequence ' + (seq.list.length + 1) });
seq.list.push(n); seq.id = n.id;
seqSave(); seqDirty(); seqRender();
});
$('seqDup').addEventListener('click', function () {
var c = seqCur(), n = seqMake(Object.assign({}, c, { name: c.name + ' copy' }));
seq.list.push(n); seq.id = n.id;
seqSave(); seqDirty(); seqRender();
});
$('seqDel').addEventListener('click', function () {
var c = seqCur(), only = seq.list.length === 1;
askConfirm(only ? 'Reset “' + c.name + '”?' : 'Delete “' + c.name + '”?', 'This can’t be undone.', only ? 'Reset' : 'Delete').then(function (yes) {
if (!yes) return;
if (only) { Object.assign(c, SEQ_DEFAULT); seqTouch(c); }
else {
seq.del[c.id] = Date.now();
seq.list = seq.list.filter(function (x) { return x.id !== c.id; });
seq.id = seq.list[0].id;
seqSave(); seqDirty();
}
seqRender();
});
});
$('seqShare').addEventListener('click', function () { shareText('Motor Checker sequence', seqShareText(seqCur())); });
$('seqCsv').addEventListener('click', function () { downloadCsv('motorchecker_sequences.csv', seqCsv(), { count: seq.list.length, one: 'sequence', many: 'sequences' }); });
$('resetSeqBtn').addEventListener('click', function () {
askConfirm('Reset all sequences?', 'Every saved sequence is deleted, here and on the device. This can’t be undone.', 'Reset all').then(function (yes) {
if (!yes) return;
var now = Date.now();
seq.list.forEach(function (x) { seq.del[x.id] = now; });
var first = seqMake();
first.auto = true;
seq.list = [first]; seq.id = first.id;
seqSave(); seqDirty(); seqRender();
$('dataActionStatus').textContent = 'All sequences were reset.';
$('dataActionStatus').className = 'status ok';
});
});
seqLoad();
seqRender();
}
buildSequence();
fetch('/deviceid').then(function (r) { return r.json(); }).then(function (d) {
deviceKey = d.id;
setDevName(d.name, d.devId);
$('devId').value = d.devId;
pin = loadPin();
if (!pin) { showGate(); return; }
api('/telemetry').then(start).catch(function (err) {
if (err.code === 401) showGate('Enter the PIN shown at power-up.');
else setConn('bad', 'disconnected');
});
}).catch(function () {
setConn('bad', 'no device');
if (navigator.serial) showGate('Not on the device’s Wi-Fi? Connect with the USB cable.');
});
})();
